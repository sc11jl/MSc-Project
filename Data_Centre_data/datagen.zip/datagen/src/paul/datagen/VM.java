/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul.datagen;

/**
 *
 * @author Paul
 */
public class VM
{
    /*
    VM_No, Node_No, CPU-Utilisation, Disk-Utilisation, Memory-Utilisation
    */
    
    private static int rollingNum = 0;
    public int number;
    public int nodeNumber;
    public double CPU;
    public double DISK;
    public double MEM;
    
    public VM(int node, double c, double d, double m)
    {
        nodeNumber = node;
        number = rollingNum++;
        CPU = c;
        DISK = d;
        MEM = m;
    }
}
