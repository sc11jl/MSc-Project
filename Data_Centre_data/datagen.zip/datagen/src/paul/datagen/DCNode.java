/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul.datagen;

/**
 *
 * @author Paul
 */
public class DCNode
{
    /*
        One for node information:
        Node_No, Rack_No, CPU-Utilisation, Disk-Utilisation, Memory-Utilisation, Power-Consumption, PUE value.
    */
    
    public int number;
    public double CPU_Util;
    public double Disk_Util;
    public double Mem_Util;
    public double Power_Consump;
    
    public DCNode(int n, double c, double d, double m, double pc)
    {
        number = n;
        CPU_Util = c;
        Disk_Util = d;
        Mem_Util = m;
        Power_Consump = pc;
    }
}
