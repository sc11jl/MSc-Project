/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul.datagen;

import java.io.PrintWriter;
import java.util.ArrayList;


/**
 *
 * @author Paul Townend
 */
public class MainMethod
{
    public static void main(String args[])
    {
        Generate theGenerator = new Generate();

        for (int time = 0; time < 100; time += 5)
        {
            theGenerator.writeToNodeFile(time);
            theGenerator.writeToVMFile(time);
            theGenerator.timestepDC();
        }


        
    }   

    
}
