/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paul.datagen;


import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 *
 * @author Paul Townend
 */
public class Generate
{
  /*
        One for node information:
        Node_No, Rack_No, CPU-Utilisation, Disk-Utilisation, Memory-Utilisation, Power-Consumption, PUE value.
        Another for VM information: 
        VM_No, Node_No, CPU-Utilisation, Disk-Utilisation, Memory-Utilisation.
    */
    
    final int MAX_NODES = 1000;
    final int MAX_RACKSIZE = 42;
    final int MIN_RACKSIZE = 36;
    final int MIN_CUSTOMERS = 12;
    final int MAX_CUSTOMERS = 30;
    
    ArrayList AvailableNodes;
    ArrayList RackSizes;
    ArrayList FilledRacks;
    ArrayList VMList;
    
    boolean nodeFileStart = true;
    boolean vmFileStart = true;
    
    Random RandGenerator = new Random();
    
    // constructor
    public Generate()
    {
        generateNodes();
        generateRackSizes();
        fillRacks();
        generateVMsAndModifyRacks();
    }
    
    
    
    public void timestepDC()
    {
        // WIPE THE OLD VMLIST
        VMList.clear();
        
        // update Nodes
        for (int rackcount = 0; rackcount < FilledRacks.size(); rackcount++)
        {
            // get the rack
            ArrayList currentRack = (ArrayList) FilledRacks.get(rackcount);

            // get the nodes
            for (int nodecount = 0; nodecount < currentRack.size(); nodecount++)
            {
                // modify the node then update the VMs
                DCNode currentNode = (DCNode) currentRack.get(nodecount);
                
                // if the node has failed, there is a small chance it'll come back on
                if (currentNode.Power_Consump == 0 && currentNode.CPU_Util == 0 && RandGenerator.nextInt(100) == 45)
                {
                    currentNode = makeNode(currentNode.number);
                }
                
                int diceRoll = RandGenerator.nextInt(100);
                
                // bump up CPU, MEM, DISK, etc.
                if (diceRoll > 55)
                {
                    currentNode.CPU_Util += (RandGenerator.nextDouble() * 6);
                    currentNode.Disk_Util += (RandGenerator.nextDouble() * 6);
                    currentNode.Mem_Util += (RandGenerator.nextDouble() * 6);
                    currentNode.Power_Consump += (RandGenerator.nextDouble() * 6);                
                    if (currentNode.CPU_Util > 80 && currentNode.CPU_Util < 90) currentNode.CPU_Util = 80;
                    if (currentNode.Disk_Util > 80 && currentNode.Disk_Util < 90) currentNode.Disk_Util = 80;
                    if (currentNode.Mem_Util > 80 && currentNode.Mem_Util < 90) currentNode.Mem_Util = 80;
                    if (currentNode.Power_Consump > 110 && currentNode.CPU_Util < 120) currentNode.Power_Consump = 110;
                }
                else if (diceRoll < 45)
                {
                    currentNode.CPU_Util -= (RandGenerator.nextDouble() * 6);
                    currentNode.Disk_Util -= (RandGenerator.nextDouble() * 6);
                    currentNode.Mem_Util -= (RandGenerator.nextDouble() * 6);
                    currentNode.Power_Consump -= (RandGenerator.nextDouble() * 6);                
                    if (currentNode.CPU_Util < 20 && currentNode.CPU_Util > 10) currentNode.CPU_Util = 20;
                    if (currentNode.Disk_Util < 20 && currentNode.Disk_Util > 10) currentNode.Disk_Util = 20;
                    if (currentNode.Mem_Util < 20 && currentNode.Mem_Util > 10) currentNode.Mem_Util = 20;
                    if (currentNode.Power_Consump < 40 && currentNode.CPU_Util > 10) currentNode.Power_Consump = 40;
                }
                
                // now update the VMs - just randomly change based on node values so this will be choppy!!!!
                
                // for each node, if it is turned on, then generate 1-8 VMs
                if (currentNode.CPU_Util > 0)
                {
                    double remainingCPU = currentNode.CPU_Util;
                    double remainingDISK = currentNode.Disk_Util;
                    double remainingMEM = currentNode.Mem_Util;

                    int numVMs = RandGenerator.nextInt(8)+ 1;
                    for (int count3 = 0; count3 < numVMs; count3++)
                    {
                        double vmCPU = RandGenerator.nextDouble() * remainingCPU;
                        double vmDISK = RandGenerator.nextDouble() * remainingDISK;
                        double vmMEM = RandGenerator.nextDouble() * remainingMEM;
                        if (count3 == numVMs -1)
                        {
                            vmCPU = remainingCPU;
                            vmDISK = remainingDISK;
                            vmMEM = remainingMEM;
                        }

                        remainingCPU -= vmCPU;
                        remainingDISK -= vmDISK;
                        remainingMEM -= vmMEM;

                        VMList.add(new VM(currentNode.number, vmCPU, vmDISK, vmMEM));
                    }
                }

            }
        }
    }

    
    
    
    public void generateVMsAndModifyRacks()
    {
        VMList = new ArrayList();
        
        // go through each rack and generate VMs per node and fail racks etc when necessary
        for (int count = 0; count < FilledRacks.size(); count++)
        {
            // get the rack
            ArrayList currentRack = (ArrayList) FilledRacks.get(count);

            // let's fail or retard a few racks
            int diceRoll = RandGenerator.nextInt(1000);
            boolean hasRackFailed = (diceRoll == 823 || diceRoll == 167);
            boolean hasRackDiskFailed = (diceRoll == 432 || diceRoll == 120);


            // go through each node in the rack and generate VMs
            for (int count2 = 0; count2 < currentRack.size(); count2++)
            {
                DCNode currentNode = (DCNode) currentRack.get(count2);

                // if the rack has failed, make everything 0
                if (hasRackFailed)
                {
                    currentNode.CPU_Util = 0;
                    currentNode.Disk_Util = 0;
                    currentNode.Mem_Util = 0;
                    currentNode.Power_Consump = 0;
                }
                else if (hasRackDiskFailed)
                {
                    currentNode.Disk_Util = 0;
                }

                // for each node, if it is turned on, then generate 1-8 VMs
                if (currentNode.CPU_Util > 0)
                {
                    double remainingCPU = currentNode.CPU_Util;
                    double remainingDISK = currentNode.Disk_Util;
                    double remainingMEM = currentNode.Mem_Util;

                    int numVMs = RandGenerator.nextInt(8)+ 1;
                    for (int count3 = 0; count3 < numVMs; count3++)
                    {
                        double vmCPU = RandGenerator.nextDouble() * remainingCPU;
                        double vmDISK = RandGenerator.nextDouble() * remainingDISK;
                        double vmMEM = RandGenerator.nextDouble() * remainingMEM;
                        if (count3 == numVMs -1)
                        {
                            vmCPU = remainingCPU;
                            vmDISK = remainingDISK;
                            vmMEM = remainingMEM;
                        }

                        remainingCPU -= vmCPU;
                        remainingDISK -= vmDISK;
                        remainingMEM -= vmMEM;

                        VMList.add(new VM(currentNode.number, vmCPU, vmDISK, vmMEM));
                    }
                    
                }
            
            // end of count2 loop
            }
         
        // end of count loop
        }

        System.out.println("Generated " + VMList.size() + " VMs for the data centre");
    }
    
    
    public void generateNodes()
    {
        // generate MAX_NODES nodes - not all of these will probably be used
        AvailableNodes = new ArrayList();
        int diceRoll;
        
        for (int count = 1; count <= MAX_NODES; count++)
        {
            // add to the pool
            AvailableNodes.add(makeNode(count));
        }
        
        System.out.println("Generated " + MAX_NODES + " nodes");
    }
    
    
    public DCNode makeNode(int number)
    {
        int diceRoll;
        
        // CPU util is between 20 and 70, unless outlier
            double CPU = (RandGenerator.nextDouble() * 50) + 20;
            diceRoll = RandGenerator.nextInt(100);
            if (diceRoll > 97) CPU = (RandGenerator.nextDouble() * 2) + 98; else if (diceRoll < 2) CPU = 0;
            
            // MEM util is between 20 and 70, unless outlier
            double MEM = (RandGenerator.nextDouble() * 50) + 20;
            diceRoll = RandGenerator.nextInt(100);
            if (diceRoll > 97) MEM = (RandGenerator.nextDouble() * 2) + 98; else if (diceRoll < 2) MEM = 0;
            
            // DISK util is between 20 and 70, unless outlier
            double DISK = (RandGenerator.nextDouble() * 50) + 20;
            diceRoll = RandGenerator.nextInt(100);
            if (diceRoll > 97) DISK = (RandGenerator.nextDouble() * 2) + 98; else if (diceRoll < 2) DISK = 0;
            
            // power consumption is between 40 and 100 watts, unless crazy
            double POWER = (RandGenerator.nextDouble() * 60) + 40;
            diceRoll = RandGenerator.nextInt(100);
            if (diceRoll > 97) POWER = (RandGenerator.nextDouble() * 60) + 80;
                    
            // machine failure
            diceRoll = RandGenerator.nextInt(300);
            if (diceRoll == 16 || diceRoll == 184 || diceRoll == 237 || diceRoll == 289) { CPU = 0; MEM = 0; DISK = 0; POWER = 0;}
            
            return new DCNode(number, CPU, MEM, DISK, POWER);
            
    }
    
    
    public void fillRacks()
    {
        Iterator rackIter = RackSizes.iterator();
        FilledRacks = new ArrayList();
        
        while (rackIter.hasNext())
        {
            int currentRackSize = (Integer) rackIter.next();
            
            // for currentRack, pick the number of nodes
            ArrayList currentRack = new ArrayList();
            
            for (int count = 0; count < currentRackSize; count++)
            {
                int pickedNode = RandGenerator.nextInt(AvailableNodes.size());
                currentRack.add(AvailableNodes.get(pickedNode));
                AvailableNodes.remove(pickedNode);
            }
            
            FilledRacks.add(currentRack);
        }
        
        System.out.println("Filled all racks");
    }
    
    
    public void generateRackSizes()
    {
        boolean filled;
        int numNodes = 0;
        RackSizes = new ArrayList();
        
        while (numNodes < (MAX_NODES - MIN_RACKSIZE))
        {
            int currentRackSize = 0;
            // special last case
            if (numNodes > (MAX_NODES - MAX_RACKSIZE))
            {
                while (currentRackSize > (MAX_NODES - MAX_RACKSIZE) || currentRackSize < MIN_RACKSIZE) currentRackSize = (RandGenerator.nextInt((MAX_NODES - numNodes) - 1)+1);
            }
            else
            {
                while (currentRackSize < MIN_RACKSIZE) currentRackSize = RandGenerator.nextInt(MAX_RACKSIZE-1)+1;
            }
            
            numNodes += currentRackSize;
            RackSizes.add(currentRackSize);
        }    
        
        System.out.println("Generated " + RackSizes.size() + " racks for " + numNodes + " nodes.");
    }
    
    
    public void writeToVMFile(double timestamp)
    {
        // output to VM file
        try
        {
            File theFile = new File("VMData.csv");
            if (vmFileStart) if (theFile.exists()) theFile.delete(); // if we are starting a new run and an existing file is there, then delete it first
            
            PrintWriter nodeWriter = new PrintWriter(new FileOutputStream(theFile,true));
            
            if (vmFileStart) 
            {
                nodeWriter.println("Timestamp,VM_No,Node_No,CPU-Utilisation,Disk-Utilisation,Memory-Utilisation");
                vmFileStart = false;
            }
            
            
            // go through node list and print - don't bother with iterators
            for (int currentVM = 0; currentVM < VMList.size(); currentVM++)
            {
                String LineToWrite = "";
                VM theVM = (VM) VMList.get(currentVM);
                LineToWrite = "" + timestamp + ",";
                LineToWrite += theVM.number + ",";
                LineToWrite += theVM.nodeNumber + ",";
                LineToWrite += theVM.CPU + ",";
                LineToWrite += theVM.DISK + ",";
                LineToWrite += theVM.MEM;
                nodeWriter.println(LineToWrite);

            }
            nodeWriter.close();
            System.out.println("Written VM data file");
        }
        catch (Exception e)
        {
            System.err.println("Error writing VM file");
            e.printStackTrace();
        }
        
    }
    
    public void writeToNodeFile(double timestamp)
    {
        // output to node file
        try
        {
            File theFile = new File("NodeData.csv");
            
            if (nodeFileStart) if (theFile.exists()) theFile.delete(); // if we are starting a new run and an existing file is there, then delete it first
            
            PrintWriter nodeWriter = new PrintWriter(new FileOutputStream(theFile,true));
            
            if (nodeFileStart) 
            {
                nodeWriter.println("Timestamp,Node_No,Rack_No,CPU-Utilisation,Disk-Utilisation,Memory-Utilisation,Power-Consumption");
                nodeFileStart = false;
            }


            // go through node list and print - don't bother with iterators
            for (int currentRack = 0; currentRack < FilledRacks.size(); currentRack++)
            {
                String LineToWrite = "";

                ArrayList nodeList = (ArrayList) FilledRacks.get(currentRack);
                for (int currentNode = 0; currentNode < nodeList.size(); currentNode++)
                {
                    DCNode theNode = (DCNode) nodeList.get(currentNode);
                    
                    LineToWrite = "" + timestamp + ",";
                    LineToWrite += theNode.number + ",";
                    LineToWrite += (currentRack+1) + ",";
                    LineToWrite += theNode.CPU_Util + ",";
                    LineToWrite += theNode.Disk_Util + ",";
                    LineToWrite += theNode.Mem_Util + ",";
                    LineToWrite += theNode.Power_Consump;

                    nodeWriter.println(LineToWrite);
                }
            }

            nodeWriter.close();
            System.out.println("Written Node data file");
        }
        catch (Exception e)
        {
            System.err.println("Error writing node file");
            e.printStackTrace();
        }


    }
       
}
